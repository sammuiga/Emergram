package com.sammuiga.emergram

class PlaceModel(
    var id: Int,
    var drawableId: Int,
    var name: String,
    var placeType: String
)