package com.sammuiga.emergram.ui.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.sammuiga.emergram.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}